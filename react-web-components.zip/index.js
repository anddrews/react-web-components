import React from 'react';
import ReactDOM from 'react-dom';

import {App} from './src/app';

ReactDOM.render(<App />, document.getElementById('root'));


