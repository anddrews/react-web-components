import React from 'react';

import 'web-components';

export const App = () => (
  <div style={{width: '300px'}}>
    <cb-chat-header data-greeting=";k;k;k;k"/>
    <cb-chat-header data-greeting="hhhhhhhhhh"/>
    <cb-chat-header data-greeting="eeeeeeeee"/>
    Hello world
  </div>
);
