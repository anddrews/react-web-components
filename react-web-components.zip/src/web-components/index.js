import {ChatHeader} from './chat-header/chat-header';

(() => {
  customElements.define("cb-chat-header", ChatHeader);
})();
