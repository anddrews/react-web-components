import classnames from 'classnames/bind';

export const styleNames = (styles) => classnames.bind(styles);
